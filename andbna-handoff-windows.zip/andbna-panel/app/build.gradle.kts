plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.chaquo.python")
}

android {
    namespace = "com.wjljh.andbna"
    compileSdk = 37
    buildToolsVersion = "37.0.0"

    defaultConfig {
        // 与旧版 com.wjljh.andbna.panel.debug 并存：用独立包名，签名不同也不冲突
        applicationId = "com.wjljh.andbna.qbot"
        minSdk = 26
        targetSdk = 37
        versionCode = 110
        versionName = "1.1.0"

        // 只出 arm64-v8a（设备为 arm64 Android 17）
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

chaquopy {
    defaultConfig {
        // 设备端是 3.13，Chaquopy 强制 buildPython 必须同版本
        version = "3.13"
        buildPython("/home/wjljh/toolchain/python313/python/bin/python3")
        pip {
            install("qq-botpy==1.2.1")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.19.1")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.material3:material3:1.5.0-beta01")
    implementation("top.yukonga.miuix.kmp:miuix-ui-android:0.9.4")
    implementation("top.yukonga.miuix.kmp:miuix-icons-android:0.9.4")
}
