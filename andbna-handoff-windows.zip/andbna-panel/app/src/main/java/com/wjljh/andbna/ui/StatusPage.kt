package com.wjljh.andbna.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Backup
import top.yukonga.miuix.kmp.icon.extended.Community
import top.yukonga.miuix.kmp.icon.extended.Info
import top.yukonga.miuix.kmp.icon.extended.Link
import top.yukonga.miuix.kmp.icon.extended.Messages
import top.yukonga.miuix.kmp.icon.extended.Notes
import top.yukonga.miuix.kmp.icon.extended.Ok
import top.yukonga.miuix.kmp.icon.extended.Play
import top.yukonga.miuix.kmp.icon.extended.Refresh
import top.yukonga.miuix.kmp.icon.extended.Settings
import top.yukonga.miuix.kmp.icon.extended.Timer
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun StatusPage(metrics: Metrics, visible: Boolean) {
    val scope = rememberCoroutineScope()
    var logText by remember { mutableStateOf("") }
    var llmMsg by remember { mutableStateOf("") }
    var llmOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf("") }

    // 只有这个页在显示时才轮询。之前四个页面各自无限循环，
    // 离开组合才停；现在至少不会在别的页面上偷偷发请求。
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (true) {
            Store.refreshStatus()
            delay(3000)
        }
    }

    val bot = Store.statusBot()
    val wd = Store.statusWatchdog()
    val net = Store.statusNet()
    val running = bot?.optBoolean("running") == true
    val netOk = net?.optBoolean("ok") == true

    val state = when {
        Store.status == null && Store.statusErr.isNotBlank() -> Triple("未连接", Tokens.Bad, "连不上面板服务")
        Store.status == null -> Triple("读取中", Tokens.Idle, "正在读取面板状态")
        running && netOk -> Triple("工作中", Tokens.Ok, "bot 在线，网络通畅")
        !running -> Triple("已停止", Tokens.Bad, "bot 进程没在跑")
        else -> Triple("网络异常", Tokens.Bad, "QQ 接口连不上，bot 会反复重连")
    }
    val modeLabel = com.wjljh.andbna.local.ModeStore.get(
        androidx.compose.ui.platform.LocalContext.current
    )?.label ?: "未选模式"

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
    ) {
        PageColumn(metrics) {
            HeroCard(metrics, state.first, state.second, state.third)

            // 信息行自带 24dp 下间距（spec §6 #8），所以这里的 gap 必须是 0，
            // 不能和 SectionCard 的行距叠加。
            SectionCard(metrics, gap = 0.dp) {
                InfoRow(metrics, MiuixIcons.Info, "面板版本", Store.version.ifBlank { "未连接" })
                InfoRow(metrics, MiuixIcons.Link, "面板地址", Panel.host.ifBlank { "127.0.0.1:8788" })
                InfoRow(metrics, MiuixIcons.Settings, "运行模式", modeLabel)
                InfoRow(
                    metrics,
                    MiuixIcons.Community, "bot 进程",
                    when {
                        bot == null -> "-"
                        running -> "pid ${bot.optInt("pid")} · 已跑 ${fmtDur(bot.optInt("uptime_sec"))}"
                        else -> "没在跑"
                    },
                )
                InfoRow(
                    metrics,
                    MiuixIcons.Refresh, "看门狗",
                    when {
                        wd == null -> "-"
                        wd.optBoolean("running") ->
                            "运行中" + wd.optString("appid").let { if (it.isBlank()) "" else " · 守护 $it" }
                        else -> "没在跑"
                    },
                )
                InfoRow(
                    metrics,
                    MiuixIcons.Timer, "内存 / CPU",
                    if (bot == null) "-"
                    else "${bot.optDouble("rss_mb")} MB · 累计 ${bot.optDouble("cpu_sec")} 秒",
                    last = true,
                )
            }

            SectionCard(metrics, title = "快捷操作") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ConfirmButton(text = "重启 bot", confirmText = "确认重启？", danger = true) {
                        scope.launch {
                            busy = "正在重启…"
                            val r = Panel.restart("bot")
                            busy = if (r.ok) "" else "重启失败：" + r.err()
                            delay(2500)
                            Store.refreshStatus(0)
                        }
                    }
                    ConfirmButton(text = "重启看门狗", confirmText = "确认重启？", danger = false) {
                        scope.launch {
                            busy = "正在拉起看门狗…"
                            val r = Panel.restart("watchdog")
                            busy = if (r.ok) "" else "失败：" + r.err()
                            Store.refreshStatus(0)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionChip("试跑模型") {
                        scope.launch {
                            llmMsg = "正在调模型…"
                            llmOk = true
                            val r = Panel.testLlm()
                            llmOk = r.ok
                            llmMsg = if (r.ok) {
                                "可用 · ${r.json?.optInt("ms")}ms · ${r.str("reply").ifBlank { "（空回复）" }}"
                            } else {
                                "失败：" + r.err()
                            }
                        }
                    }
                    ActionChip("读日志") {
                        scope.launch {
                            val r = Panel.log(150)
                            logText = if (r.ok) {
                                val arr = r.arr("lines")
                                buildString {
                                    if (arr != null) for (i in 0 until arr.length()) {
                                        append(arr.optString(i)).append('\n')
                                    }
                                }.ifBlank { "（日志是空的）" }
                            } else {
                                "读取失败：" + r.err()
                            }
                        }
                    }
                }
                if (busy.isNotBlank()) Note(busy)
                if (llmMsg.isNotBlank()) Note(llmMsg, llmOk)
            }

            if (logText.isNotBlank()) {
                SectionCard(metrics, title = "日志（最近 150 行）") {
                    Text(
                        logText,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
        }
    }
}

/**
 * 顶部状态卡 = SukiSU 首页那张 hero 卡（spec §1.3 / §2.2 / §6 #2-#6）。
 *
 * 三条硬规矩：
 * 1. 只有「工作中」整卡实色染色，其余状态走 Card 默认底 —— 不给空闲态染色；
 * 2. 内沿 0dp，内文自己给 padding(16,14) / (16,10)；
 * 3. 对角大图标 110dp 摆在 BottomEnd 再往外偏移，靠卡片裁剪切出「对角」感。
 */
@Composable
private fun HeroCard(metrics: Metrics, title: String, tint: Color, subtitle: String) {
    val modeLabel = com.wjljh.andbna.local.ModeStore.get(LocalContext.current)?.label ?: "本机托管"
    val working = title == "工作中"

    // spec §1.3：优先级 动态色 > 暗 > 亮
    val bg: Color? = when {
        !working -> null
        MiuixTheme.isDynamicColor -> MiuixTheme.colorScheme.secondaryContainer
        isSystemInDarkTheme() -> Tokens.OkSurfaceDark
        else -> Tokens.OkSurfaceLight
    }
    // spec §1.3：大图标 tint —— 动态色 primary@80%，否则 #36D167。
    // 非工作态不用绿勾（spec 没给空闲态图标色），退回次要文字色。
    val iconTint = when {
        !working -> MiuixTheme.colorScheme.onSurfaceVariantSummary
        MiuixTheme.isDynamicColor -> MiuixTheme.colorScheme.primary.copy(alpha = 0.8f)
        else -> Tokens.OkIcon
    }
    // spec §6 #10：主文字读 onSurface；空闲/异常态沿用原来的状态色（spec 未覆盖这档）
    val titleColor = if (working) MiuixTheme.colorScheme.onSurface else tint

    Card(
        cornerRadius = metrics.radiusCard,
        // spec #3：内沿 0dp
        insideMargin = PaddingValues(0.dp),
        colors = if (bg == null) CardDefaults.defaultColors()
        else CardDefaults.defaultColors(color = bg),
        // 卡高110dp 是【推算】值（spec §6 #2 / §7.4 第 1 条）：SukiSU 无显式高度，
        // 由 110dp 图标撑起来，这里直接写死同一个数字，实测后可再调。
        modifier = Modifier.fillMaxWidth().height(metrics.heroHeight),
    ) {
        Box(Modifier.fillMaxSize()) {
            // spec §2.2：110dp 图标 + offset(27,31)，BottomEnd，靠 Card 的裁剪切角
            Icon(
                tintIcon(title),
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 27.dp, y = 31.dp)
                    .size(metrics.heroHeight),
            )
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 16.dp, top = 14.dp, end = 16.dp),
            ) {
                Text(
                    title,
                    fontSize = metrics.titleSize,
                    fontWeight = FontWeight.SemiBold,
                    color = titleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                // spec §2.2：主标题下 1dp 空隙 + 版本行 15sp
                Spacer(Modifier.height(1.dp))
                Text(
                    "面板 " + Store.version.ifBlank { "—" },
                    fontSize = metrics.heroValueSize,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                // spec 未给这一行的字号，沿用原来的 11sp（信息不删，只换排版）
                Text(
                    subtitle,
                    fontSize = 11.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
            // spec §2.2 / §6 #6：模式文本 = 卡左下 16sp Medium 的「Built-in」式徽标语义
            Text(
                modeLabel,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = MiuixTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 16.dp, bottom = 10.dp),
            )
        }
    }
}

private fun tintIcon(title: String): ImageVector = when (title) {
    "工作中" -> MiuixIcons.Ok
    "已停止", "网络异常", "未连接" -> MiuixIcons.Notes
    else -> MiuixIcons.Info
}

/**
 * 带前置图标的信息行（spec §2.3 / §6 #7-#10）：
 * 无分隔线、行下 24dp（末行 0dp）、图标 24dp、标题 17sp / 值 14sp（值上 2dp）。
 */
@Composable
private fun InfoRow(
    metrics: Metrics,
    icon: ImageVector,
    title: String,
    value: String,
    last: Boolean = false,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = if (last) 0.dp else metrics.rowGap),
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = MiuixTheme.colorScheme.onSurface,
            modifier = Modifier.size(metrics.rowIcon),
        )
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(
                title,
                fontSize = metrics.rowTitleSize,
                fontWeight = FontWeight.Medium,
                color = MiuixTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                value,
                fontSize = metrics.rowValueSize,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

private fun fmtDur(sec: Int): String {
    if (sec <= 0) return "—"
    val d = sec / 86400
    val h = (sec % 86400) / 3600
    val m = (sec % 3600) / 60
    return when {
        d > 0 -> "$d 天 $h 小时"
        h > 0 -> "$h 小时 $m 分"
        m > 0 -> "$m 分"
        else -> "$sec 秒"
    }
}
