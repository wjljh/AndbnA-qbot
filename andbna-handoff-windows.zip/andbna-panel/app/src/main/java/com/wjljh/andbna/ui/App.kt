package com.wjljh.andbna.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import com.wjljh.andbna.local.ModeStore
import com.wjljh.andbna.local.RunMode
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import top.yukonga.miuix.kmp.basic.Badge
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Edit
import top.yukonga.miuix.kmp.icon.extended.Info
import top.yukonga.miuix.kmp.icon.extended.Messages
import top.yukonga.miuix.kmp.icon.extended.More
import top.yukonga.miuix.kmp.icon.extended.Settings
import top.yukonga.miuix.kmp.theme.MiuixTheme

private data class Tab(val label: String, val icon: ImageVector)

/**
 * 导航项角标。返回类型显式写成 @Composable () -> Unit，
 * 否则 when 分支里的 lambda 推断不出 composable 上下文。
 */
@Composable
private fun navBadge(index: Int, botDown: Boolean, chats: Int): (@Composable () -> Unit)? = when {
    index == 0 && botDown -> { { Badge() } }
    index == 2 && chats > 0 -> { { Badge { Text("$chats") } } }
    else -> null
}

@Composable
fun PanelApp() {
    val ctx = LocalContext.current
    val metrics = rememberMetrics()
    var mode by remember { mutableStateOf(ModeStore.initial(ctx)) }
    var showModePicker by remember { mutableStateOf(false) }
    var configured by remember { mutableStateOf(Panel.configured) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    // 图标只构造一次。ImageVector 每次重建都要重算路径，之前放在
    // composable 里每次都新建 4 个，切页时白白多算一遍 —— 卡顿来源之一。
    val tabItems = remember {
        listOf(
            Tab("状态", MiuixIcons.Info),
            Tab("文案", MiuixIcons.Edit),
            Tab("记忆", MiuixIcons.Messages),
            Tab("设置", MiuixIcons.Settings),
        )
    }

    // 运行模式退到设置里的二级页：不再拦在启动路径上
    if (showModePicker) {
        ModePickScreen(
            metrics = metrics,
            current = mode,
            allowBack = true,
            onPick = { picked ->
                ModeStore.set(ctx, picked)
                mode = picked
                showModePicker = false
            },
            onBack = { showModePicker = false },
        )
        return
    }

    // 非模块模式：界面就是「本机托管」那一页
    if (mode != RunMode.MODULE) {
        LocalModeScreen(metrics, onBack = { showModePicker = true })
        return
    }

    LaunchedEffect(configured) {
        if (configured) Store.refreshStatus(0)
    }

    if (!configured) {
        SetupGate(
            metrics,
            onDone = {
                configured = true
                Store.invalidateAll()
                scope.launch { Store.refreshStatus(0) }
            },
            onLocalMode = {
                ModeStore.set(ctx, RunMode.NORMAL)
                mode = RunMode.NORMAL
            },
        )
        return
    }

    // 首次且没配过面板 token 的情况：SetupGate 里也能直接跳去本机模式

    val subtitle = remember(Store.version, Store.activeAppid) {
        listOf(Store.version, Store.activeAppid).filter { it.isNotBlank() }
            .joinToString(" · ").ifBlank { "本地面板" }
    }

    // MiuixScrollBehavior 本身就是 @Composable，不能包在 remember{} 里
    val scrollBehavior = MiuixScrollBehavior()
    val botsChats = remember(Store.bots, Store.activeAppid) {
        val cur = Store.bots.firstOrNull { it.optString("appid") == Store.activeAppid }
            ?: Store.bots.firstOrNull { it.optBoolean("current") }
        cur?.optInt("chats") ?: 0
    }
    val botDown = Store.status != null && Store.statusBot()?.optBoolean("running") == false

    Scaffold(
        containerColor = MiuixTheme.colorScheme.surface,
        // spec §6 #18：横向 insets 自己收窄，纵向留给 TopAppBar / NavigationBar 各自处理
        contentWindowInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)
            .only(WindowInsetsSides.Horizontal),
        topBar = {
            TopAppBar(
                title = "AndbnA",
                largeTitle = "AndbnA",
                subtitle = subtitle,
                scrollBehavior = scrollBehavior,
                actions = {
                    IconButton(onClick = { tab = 3 }) {
                        Icon(MiuixIcons.More, contentDescription = "更多")
                    }
                },
            )
        },
        bottomBar = {
            // 用停靠式 NavigationBar 而不是 FloatingNavigationBar：
            // 后者官方说明是「仅显示图标」，SukiSU 那栏是带文字的。
            // 顺带好处：Scaffold 会把导航栏高度算进内容内边距，卡片不会再被遮。
            // spec §4.1 / §6 #14：栏底色显式传 surface（别吃库默认），
            // 选中态只有颜色 + Bold，胶囊/液态玻璃都不做。
            NavigationBar(color = MiuixTheme.colorScheme.surface) {
                tabItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = item.icon,
                        label = item.label,
                        badge = navBadge(index, botDown, botsChats),
                    )
                }
            }
        },
    ) { pad ->
        Box(
            Modifier
                .fillMaxSize()
                // spec §5.2 / §6 #13：pad 的 bottom 就是 bottomBar 实测高度
                // （miuix Scaffold.kt:337），页尾留白只吃这一口，页面里不再另加。
                .padding(pad)
                // 把滚动事件交给 TopAppBar，大标题才会随下滑折叠成小标题
                .nestedScroll(scrollBehavior.nestedScrollConnection),
        ) {
            when (tab) {
                0 -> StatusPage(metrics, visible = true)
                1 -> TextsPage(metrics, visible = true)
                2 -> MemoryPage(metrics, visible = true)
                else -> SettingsPage(metrics, visible = true, onBotChanged = { newActive ->
                    Store.activeAppid = newActive
                    Store.invalidateAll()
                    scope.launch { Store.refreshStatus(0) }
                }, onReselectMode = { showModePicker = true })
            }
        }
    }
}

/** 首次使用：连模块面板，或者走纯 APK 模式 */
@Composable
private fun SetupGate(metrics: Metrics, onDone: () -> Unit, onLocalMode: () -> Unit) {
    var host by remember { mutableStateOf(Panel.host) }
    var token by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    Scaffold(containerColor = MiuixTheme.colorScheme.surface) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState()),
        ) {
            PageColumn(metrics) {
                Text(
                    "AndbnA",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MiuixTheme.colorScheme.onSurface,
                )
                Text(
                    "两种用法：连模块的面板服务，或者完全不装模块、让 bot 跑在 App 里。",
                    fontSize = 13.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )

                SectionCard(metrics, title = "不需要模块", hint = "Python 运行时打包在 App 里，由前台服务托管") {
                    ActionChip("纯 APK 模式") { onLocalMode() }
                }

                SectionCard(
                    metrics,
                    title = "连接模块面板",
                    hint = "在管理器里对模块点「执行」（或 sh action.sh panel）会打印 TOKEN",
                ) {
                    LineField(host, { host = it }, "地址（默认 127.0.0.1:8788）")
                    LineField(token, { token = it }, "TOKEN", password = true)
                    if (msg.isNotBlank()) Note(msg, ok)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionChip(if (busy) "连接中…" else "连接", enabled = !busy) {
                            if (token.isBlank()) {
                                ok = false
                                msg = "TOKEN 不能为空"
                            } else {
                                busy = true
                                msg = ""
                                Panel.host = host
                                Panel.token = token
                                scope.launch {
                                    val r = Panel.health()
                                    busy = false
                                    if (r.ok) {
                                        ok = true
                                        msg = "连上了：" + r.str("version")
                                        onDone()
                                    } else {
                                        ok = false
                                        msg = "连不上：" + r.err().ifBlank { "HTTP ${r.code}" }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
