package com.wjljh.andbna

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 与模块里的 panel.py 通信。
 *
 * 面板不申请 root，所有需要 root 的动作都由 panel.py 在手机本地完成，
 * 这里只发 HTTP。地址默认 127.0.0.1:8788，token 从模块里读一次后存起来。
 */
object Panel {

    private const val PREF = "andbna_panel"
    private const val DEFAULT_HOST = "127.0.0.1:8788"

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) {
            prefs = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        }
    }

    var host: String
        get() = prefs?.getString("host", "")?.takeIf { it.isNotBlank() } ?: DEFAULT_HOST
        set(v) = prefs?.edit()?.putString("host", v.trim())?.apply() ?: Unit

    var token: String
        get() = prefs?.getString("token", "") ?: ""
        set(v) = prefs?.edit()?.putString("token", v.trim())?.apply() ?: Unit

    val configured: Boolean get() = token.isNotBlank()

    /** 拼成完整 URL：允许用户只填 127.0.0.1，也允许只填 IP */
    fun baseUrl(): String {
        var h = host.trim().ifBlank { DEFAULT_HOST }
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://$h"
        if (!h.matches(Regex("^https?://[^/]+:\\d+$"))) {
            val m = Regex("^(https?://[^/:]+)(?:.*)$").find(h)
            if (m != null) h = m.groupValues[1] + ":8788"
        }
        return h.trimEnd('/')
    }

    data class Res(val code: Int, val json: JSONObject?, val raw: String) {
        val ok: Boolean get() = code in 200..299 && (json?.optBoolean("ok", true) ?: false)
        fun err(): String =
            json?.optString("error").orEmpty().ifBlank {
                json?.optString("hint").orEmpty().ifBlank { raw.take(160) }
            }
        fun str(key: String): String = json?.optString(key).orEmpty()
        fun obj(key: String): JSONObject? = json?.optJSONObject(key)
        fun arr(key: String): org.json.JSONArray? = json?.optJSONArray(key)
    }

    suspend fun call(
        path: String,
        method: String = "GET",
        payload: JSONObject? = null,
    ): Res = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val url = URL(baseUrl() + path)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 4000
                readTimeout = 30000
                setRequestProperty("Accept", "application/json")
                if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
                if (payload != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
            }
            if (payload != null) {
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
            } ?: ""
            val json = try {
                if (raw.isBlank()) null else JSONObject(raw)
            } catch (e: Exception) {
                null
            }
            Res(code, json, raw)
        } catch (e: Exception) {
            Res(0, null, e.message ?: e.toString())
        } finally {
            conn?.disconnect()
        }
    }

    fun q(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ── 具体接口 ──
    suspend fun health() = call("/api/health")
    suspend fun status() = call("/api/status")
    suspend fun bots() = call("/api/bots")
    suspend fun useBot(appid: String) =
        call("/api/bots/use", "POST", JSONObject().put("appid", appid))

    suspend fun newBot(appid: String, secret: String, role: String, inheritLlm: Boolean) =
        call("/api/bots/new", "POST", JSONObject()
            .put("appid", appid).put("secret", secret).put("role", role)
            .put("inherit_llm", inheritLlm))

    suspend fun deleteBot(appid: String) =
        call("/api/bots/delete", "POST", JSONObject().put("appid", appid).put("confirm", "DELETE"))

    suspend fun config() = call("/api/config")
    suspend fun saveConfig(scope: String, patch: JSONObject) =
        call("/api/config", "POST", JSONObject().put("scope", scope).put("patch", patch))

    suspend fun texts() = call("/api/texts")
    suspend fun readText(name: String) = call("/api/text/" + q(name))
    suspend fun writeText(name: String, content: String) =
        call("/api/text/" + q(name), "PUT", JSONObject().put("content", content))

    suspend fun personas() = call("/api/personas")
    suspend fun usePersona(name: String) =
        call("/api/personas/use", "POST", JSONObject().put("name", name))

    suspend fun memory() = call("/api/memory")
    suspend fun deleteChat(key: String) =
        call("/api/memory/delete", "POST", JSONObject().put("key", key))
    suspend fun purgeMemory() =
        call("/api/memory/purge", "POST", JSONObject().put("confirm", "CLEAR"))
    suspend fun deleteOld(days: Int) =
        call("/api/memory/old", "POST", JSONObject().put("days", days))

    suspend fun names() = call("/api/names")
    suspend fun rename(who: String, name: String) =
        call("/api/names/rename", "POST", JSONObject().put("who", who).put("name", name))
    suspend fun unname(uid: String) =
        call("/api/names/unname", "POST", JSONObject().put("uid", uid))

    suspend fun creds() = call("/api/creds")
    suspend fun saveCreds(fields: JSONObject) =
        call("/api/creds", "PUT", JSONObject().put("fields", fields))

    suspend fun restart(target: String) =
        call("/api/restart", "POST", JSONObject().put("target", target))

    suspend fun log(lines: Int = 200) = call("/api/log?lines=$lines")
    suspend fun testLlm() = call("/api/llm/test")
}
