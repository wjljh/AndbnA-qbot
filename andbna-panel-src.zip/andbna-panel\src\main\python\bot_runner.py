# -*- coding: utf-8 -*-
"""纯 APK 模式：bot 跑在 App 自己的进程里，不依赖模块、不依赖 Termux。

和模块那套的区别只在「谁托管进程」：
    模块  = root 服务 + tmux + 看门狗
    本文件 = Android 前台服务里起一个线程

代码尽量薄，因为它只是壳：真正的人格/记忆/回复逻辑在模块那份
bot_qq_official.py 里，后续把它的核心抽过来即可。
"""
import os
import sys
import threading
import time
import traceback

_lock = threading.Lock()
_state = {
    "running": False,
    "status": "未启动",
    "started_at": 0,
    "log": [],
    "appid": "",
}
_log_path = ""
_client = None
_thread = None


def _stamp():
    return time.strftime("%m-%d %H:%M:%S")


def log(msg):
    line = "[%s] %s" % (_stamp(), msg)
    with _lock:
        _state["log"].append(line)
        if len(_state["log"]) > 600:
            del _state["log"][:200]
    print(line)
    sys.stdout.flush()
    try:
        if _log_path:
            with open(_log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass


def probe():
    """各层依赖版本自检：这套 Python 运行时到底好不好使，一眼看出来"""
    out = ["python   %s" % sys.version.split()[0],
           "platform %s" % sys.platform]
    for name in ("aiohttp", "yaml", "apscheduler", "botpy"):
        try:
            mod = __import__(name)
            out.append("%-8s %s" % (name, getattr(mod, "__version__", "ok")))
        except Exception as e:
            out.append("%-8s ✗ %r" % (name, e))
    return "\n".join(out)


def status():
    with _lock:
        st = _state["status"]
        up = _state["started_at"]
        running = _state["running"]
    if running and up:
        sec = int(time.time() - up)
        h, m = sec // 3600, (sec % 3600) // 60
        dur = ("%d 小时 %d 分" % (h, m)) if h else ("%d 分 %d 秒" % (m, sec % 60) if m else "%d 秒" % sec)
        return "%s · 已跑 %s" % (st, dur)
    return st


def is_running():
    with _lock:
        return bool(_state["running"])


def log_text(n=120):
    with _lock:
        return "\n".join(_state["log"][-int(n):])


def _set(**kw):
    with _lock:
        _state.update(kw)


class _Client(object):
    """延迟到启动时才定义，避免 import 期就把 botpy 拉进来"""

    @staticmethod
    def build(appid, secret):
        import botpy
        from botpy.message import GroupMessage, C2CMessage

        class AndbnAClient(botpy.Client):
            async def on_ready(self):
                log("已上线：「%s」" % getattr(self.robot, "name", "?"))

            async def on_at_message_create(self, message):
                log("频道@：%s" % (message.content or "")[:60])
                await message._api.post_message(
                    channel_id=message.channel_id,
                    msg_id=message.id,
                    content="（本机模式连通测试）收到：%s" % (message.content or "")[:40],
                )

            async def on_group_at_message_create(self, message):
                text = (getattr(message, "content", "") or "").strip()
                log("群@：%s" % text[:60])
                try:
                    await message._api.post_group_message(
                        group_openid=message.group_openid,
                        msg_type=0,
                        msg_id=message.id,
                        content="（本机模式连通测试）收到：%s" % text[:40],
                    )
                except Exception as e:
                    log("回群消息失败：%r" % e)

            async def on_c2c_message_create(self, message):
                text = (getattr(message, "content", "") or "").strip()
                log("私聊：%s" % text[:60])
                try:
                    await message._api.post_c2c_message(
                        openid=message.author.user_openid,
                        msg_type=0,
                        msg_id=message.id,
                        content="（本机模式连通测试）收到：%s" % text[:40],
                    )
                except Exception as e:
                    log("回私聊失败：%r" % e)

        # 群/私聊事件要 public_messages，频道要 public_guild_messages。
        # 不同 botpy 版本字段名可能有差别，所以留一条退路。
        try:
            intents = botpy.Intents(public_guild_messages=True, public_messages=True)
        except TypeError:
            intents = botpy.Intents(public_guild_messages=True)
            log("当前 botpy 不支持 public_messages，只开频道事件（群/私聊收不到）")

        return AndbnAClient(intents=intents)


def _run(appid, secret, datadir):
    global _client
    try:
        log("准备连接 QQ 开放平台…")
        log("数据目录：%s" % datadir)
        _client = _Client.build(appid, secret)
        _set(status="连接中")
        log("开始 run()（这一步会一直阻塞，直到连接结束）")
        _client.run(appid=appid, secret=secret)
        log("run() 返回了，连接已结束")
        _set(status="连接已结束", running=False)
    except Exception as e:
        log("启动失败：%s" % e)
        log(traceback.format_exc()[:1500])
        _set(status="启动失败：%s" % str(e)[:80], running=False)


def start(appid, secret, datadir):
    """返回 OK 表示线程已拉起（不代表已上线，上线看日志）"""
    global _thread, _log_path
    appid = (appid or "").strip()
    secret = (secret or "").strip()
    if not appid or not secret:
        return "缺少 AppID 或 AppSecret"
    if is_running():
        return "已经在跑了"
    try:
        os.makedirs(datadir, exist_ok=True)
    except Exception:
        pass
    _log_path = os.path.join(datadir, "local_bot.log")
    try:
        with open(_log_path, "a", encoding="utf-8") as f:
            f.write("\n===== %s 启动 =====\n" % _stamp())
    except Exception:
        pass

    _set(running=True, status="正在启动", started_at=time.time(), appid=appid, log=[])
    _thread = threading.Thread(target=_run, args=(appid, secret, datadir), daemon=True)
    _thread.start()
    return "OK"


def stop():
    global _client
    log("收到停止指令")
    try:
        if _client is not None:
            _client.close()
    except Exception as e:
        log("close() 出错（忽略）：%r" % e)
    _client = None
    _set(running=False, status="已停止")
    return "OK"


def main():
    """命令行调试用：python bot_runner.py <appid> <secret> <datadir>"""
    a = sys.argv[1:]
    if len(a) < 3:
        print("用法: bot_runner.py <appid> <secret> <datadir>")
        return 2
    print(start(a[0], a[1], a[2]))
    while is_running():
        time.sleep(1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
