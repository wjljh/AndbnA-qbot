package com.wjljh.andbna.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.theme.MiuixTheme

/**
 * 根据机型自适应的尺寸。
 *
 * 安全区（状态栏 / 挖孔 / 刘海）已经交给 Miuix 的 TopAppBar 与 Scaffold 处理，
 * 这里只算和屏幕尺寸有关的东西：字号、页边距、卡片圆角、宽屏行宽。
 */
data class Metrics(
    val compact: Boolean,
    val wide: Boolean,
    val pageGap: Dp,
    val cardGap: Dp,
    val innerGap: Dp,
    val radiusCard: Dp,
    val titleSize: TextUnit,
    val contentMax: Dp,
)

@Composable
fun rememberMetrics(): Metrics {
    val cfg = LocalConfiguration.current
    val w = cfg.screenWidthDp
    val h = cfg.screenHeightDp
    val fontScale = cfg.fontScale
    return remember(w, h, fontScale) {
        val compact = w < 380 || h < 620 || fontScale > 1.15f
        val wide = w >= 600
        Metrics(
            compact = compact,
            wide = wide,
            pageGap = if (wide) 24.dp else if (compact) 12.dp else 16.dp,
            cardGap = if (compact) 10.dp else 12.dp,
            innerGap = if (compact) 8.dp else 10.dp,
            radiusCard = if (compact) 22.dp else 26.dp,
            titleSize = if (wide) 26.sp else if (compact) 20.sp else 22.sp,
            contentMax = if (wide) 720.dp else Dp.Unspecified,
        )
    }
}

/** 页面外层：统一页边距 + 宽屏限制行宽并居中 */
@Composable
fun PageColumn(
    metrics: Metrics,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .then(
                    if (metrics.contentMax == Dp.Unspecified) Modifier
                    else Modifier.widthIn(max = metrics.contentMax)
                )
                .fillMaxWidth()
                .padding(horizontal = metrics.pageGap)
                // 底部留白：Miuix 的 Scaffold 不会把 bottomBar 高度算进内容 padding（和 Material3 不同），
                // 留 40dp 时最下面那张卡会被底部导航切一刀，改留一整条的高度。
                .padding(top = metrics.cardGap, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(metrics.cardGap),
            content = content,
        )
    }
}

/** 卡片：用 Miuix 的 Card，圆角和色板都由主题给 */
@Composable
fun SectionCard(
    metrics: Metrics,
    title: String? = null,
    hint: String? = null,
    // 子元素之间的间距。信息行卡片要传小值：它的子元素里有分隔线，
    // 每样都吃 10dp 会让行高比 SukiSU 大一倍（踩过）。
    gap: Dp = Dp.Unspecified,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        cornerRadius = metrics.radiusCard,
        insideMargin = PaddingValues(
            horizontal = if (metrics.compact) 14.dp else 18.dp,
            vertical = if (metrics.compact) 12.dp else 16.dp,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (title != null) {
            Text(
                title,
                // Miuix 的 title2 样式自带颜色，不显式给就会和暗色背景撞色
                // （第一版就是黑字黑底，几乎看不见）
                style = MiuixTheme.textStyles.title2,
                color = MiuixTheme.colorScheme.onSurface,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (hint != null) {
            Text(
                hint,
                fontSize = 11.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(
                if (gap == Dp.Unspecified) metrics.innerGap else gap
            ),
        ) {
            content()
        }
    }
}

@Composable
fun Dot(color: Color, size: Dp = 8.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color))
}

/** 一行键值：左边标签，右边值，可选状态点 */
@Composable
fun KeyValue(
    label: String,
    value: String,
    dot: Color? = null,
    mono: Boolean = false,
    valueColor: Color? = null,
) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        if (dot != null) {
            Dot(dot)
            Spacer(Modifier.size(8.dp))
        }
        Text(
            label,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(min = 88.dp),
        )
        Spacer(Modifier.size(8.dp))
        Text(
            value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** 可点的小胶囊（角色、标签、筛选） */
@Composable
fun Pill(
    text: String,
    selected: Boolean = false,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val bg = when {
        danger -> MaterialTheme.colorScheme.error
        selected -> Tokens.Pink
        // 之前用的 surfaceVariant 在这个桥接色板下和卡片底一个色，胶囊形同虚设
        // （截图里人格选项就是一堆裸文字），改成 onSurface 的低透明度叠层。
        else -> MiuixTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    }
    val fg = when {
        danger || selected -> Color.White
        else -> MiuixTheme.colorScheme.onSurface
    }
    Text(
        text = text,
        fontSize = 13.sp,
        color = fg,
        fontWeight = if (selected || danger) FontWeight.Medium else FontWeight.Normal,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        maxLines = 1,
    )
}

/**
 * 两段式确认按钮。
 *
 * 为什么不用对话框：模块 WebUI 里 window.confirm 被 WebView 直接拦掉，点删除毫无反应。
 * 这里点第一次只"上膛"（按钮变文案），6 秒内再点才真执行，误触也不会出事。
 */
@Composable
fun ConfirmButton(
    text: String,
    confirmText: String = "再点一次确认",
    danger: Boolean = true,
    enabled: Boolean = true,
    onConfirm: () -> Unit,
) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(6000)
            armed = false
        }
    }
    TextButton(
        text = if (armed) confirmText else text,
        onClick = {
            if (armed) {
                armed = false
                onConfirm()
            } else {
                armed = true
            }
        },
        enabled = enabled,
        colors = if (armed || danger) ButtonDefaults.textButtonColorsPrimary()
        else ButtonDefaults.textButtonColors(),
    )
}

/** 普通操作按钮 */
@Composable
fun ActionChip(text: String, enabled: Boolean = true, tone: Color? = null, onClick: () -> Unit) {
    TextButton(
        text = text,
        onClick = onClick,
        enabled = enabled,
        colors = if (tone != null || !enabled) ButtonDefaults.textButtonColorsPrimary()
        else ButtonDefaults.textButtonColors(),
    )
}

@Composable
fun LineField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    singleLine: Boolean = true,
    password: Boolean = false,
    numeric: Boolean = false,
    minLines: Int = 1,
    modifier: Modifier = Modifier,
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        singleLine = singleLine,
        minLines = minLines,
        maxLines = if (singleLine) 1 else Int.MAX_VALUE,
        visualTransformation =
            if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text
        ),
        textStyle = TextStyle(
            fontSize = 14.sp,
            fontFamily = if (password) FontFamily.Monospace else FontFamily.Default,
        ),
        modifier = modifier.fillMaxWidth(),
    )
}

/** 页面里的提示条（成功 / 失败 / 说明） */
@Composable
fun Note(text: String, ok: Boolean = true, mono: Boolean = false) {
    if (text.isBlank()) return
    val bg = if (ok) MaterialTheme.colorScheme.surfaceVariant
    else MaterialTheme.colorScheme.errorContainer
    val fg = if (ok) MaterialTheme.colorScheme.onSurfaceVariant
    else MaterialTheme.colorScheme.onErrorContainer
    Text(
        text = text,
        fontSize = 12.sp,
        color = fg,
        fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 9.dp),
    )
}

@Composable
fun Gap(h: Dp = 4.dp) = Spacer(Modifier.height(h))
