package com.wjljh.andbna.local

import android.content.Context
import java.io.File

/**
 * APK 内置的人格档。
 *
 * 为什么打包进来：纯 APK 模式没有模块、没有面板，人格只能自带。
 * 这些文件就是从模块的 texts/personas/ 原样复制进来的，
 * 三档（精简 / 精华 / 完整）都在，选哪档由用户决定。
 */
object PersonaAssets {

    private const val DIR = "personas"
    private const val PREF = "andbna_local"
    private const val KEY = "local_persona"

    /** 列出内置档名（去掉 .txt） */
    fun list(ctx: Context): List<String> = try {
        ctx.assets.list(DIR)?.mapNotNull { it.removeSuffix(".txt").takeIf { n -> n.isNotBlank() } }
            ?.sorted() ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun selected(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "") ?: ""

    /** 选中并落到运行目录，返回写入的字数（0 表示失败） */
    fun select(ctx: Context, name: String): Int {
        return try {
            val text = ctx.assets.open("$DIR/$name.txt").bufferedReader().use { it.readText() }
            val dir = File(ctx.filesDir, "localbot").apply { mkdirs() }
            File(dir, "persona.txt").writeText(text.trim() + "\n")
            File(dir, "persona_name.txt").writeText(name + "\n")
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY, name).apply()
            text.trim().length
        } catch (e: Exception) {
            0
        }
    }

    /** 三档分组，和模块那边的命名一致（-完整 / -精华 / 无后缀=精简） */
    fun group(ctx: Context): Map<String, List<String>> {
        val all = list(ctx)
        val out = LinkedHashMap<String, MutableList<String>>()
        out["完整"] = mutableListOf()
        out["精华"] = mutableListOf()
        out["精简"] = mutableListOf()
        all.forEach { n ->
            when {
                n.endsWith("-完整") -> out["完整"]!!.add(n)
                n.endsWith("-精华") -> out["精华"]!!.add(n)
                else -> out["精简"]!!.add(n)
            }
        }
        return out.filterValues { it.isNotEmpty() }
    }
}
