package com.wjljh.andbna.ui

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.local.BotHost
import com.wjljh.andbna.local.BotService
import com.wjljh.andbna.local.PersonaAssets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Back
import top.yukonga.miuix.kmp.theme.MiuixTheme

/**
 * 纯 APK 模式：不装模块、不装 Termux、不要 root，bot 直接跑在这个 App 里。
 *
 * 保活靠前台服务（通知栏挂一条）。代价是遇到厂商省电策略仍可能被杀，
 * 所以这里把「运行状态」和日志直接摆出来，掉线一眼能看出来。
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LocalModeScreen(metrics: Metrics, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var appid by remember { mutableStateOf(Prefs.get(ctx, "local_appid")) }
    var secret by remember { mutableStateOf(Prefs.get(ctx, "local_secret")) }
    var status by remember { mutableStateOf(BotHost.statusLine()) }
    var probeText by remember { mutableStateOf("") }
    var logText by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    // Android 13+ 不给通知权限的话，前台服务的通知是看不见的，
    // 用户会以为「启动了但没反应」，所以第一次启动时顺手要一下。
    val askNotif = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            msgOk = false
            msg = "没给通知权限：bot 仍在跑，但通知栏看不到，也更容易被系统清掉"
        }
    }

    LaunchedEffect(Unit) {
        // 「默认开启」：配过凭据就直接拉起来，不每次让用户点启动
        val savedId = Prefs.get(ctx, "local_appid")
        val savedSecret = Prefs.get(ctx, "local_secret")
        if (savedId.isNotBlank() && savedSecret.isNotBlank() && !BotHost.isRunning()) {
            BotHost.init(ctx)
            BotService.start(ctx, savedId, savedSecret)
        }
        while (true) {
            status = BotHost.statusLine()
            logText = BotHost.logTail(150)
            delay(2000)
        }
    }

    Scaffold(
        containerColor = MiuixTheme.colorScheme.surface,
        topBar = {
            SmallTopAppBar(
                title = "纯 APK 模式",
                subtitle = "不需要模块 / Termux / root",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(MiuixIcons.Back, contentDescription = "返回")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState()),
        ) {
            PageColumn(metrics) {
                Note(
                    "Python 运行时和 botpy 都打包在 App 里，bot 由前台服务托管（通知栏会挂一条）。"
                )
                if (msg.isNotBlank()) Note(msg, msgOk)

                SectionCard(metrics, title = "运行状态", hint = BotHost.dataDir(ctx).absolutePath) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Dot(if (BotHost.isRunning()) Tokens.Ok else Tokens.Idle)
                        Text(
                            status.ifBlank { "未启动" },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(start = 8.dp),
                            color = MiuixTheme.colorScheme.onSurface,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionChip("启动") {
                            if (appid.isBlank() || secret.isBlank()) {
                                msgOk = false
                                msg = "先把 AppID 和 AppSecret 填上"
                            } else {
                                Prefs.put(ctx, "local_appid", appid)
                                Prefs.put(ctx, "local_secret", secret)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                BotHost.init(ctx)
                                BotService.start(ctx, appid.trim(), secret.trim())
                                msgOk = true
                                msg = "已拉起前台服务，看下面的日志"
                                scope.launch {
                                    delay(1500)
                                    status = BotHost.statusLine()
                                    logText = BotHost.logTail(150)
                                }
                            }
                        }
                        ActionChip("停止") {
                            BotService.stop(ctx)
                            msgOk = true
                            msg = "已请求停止"
                        }
                        ActionChip("自检") {
                            busy = true
                            scope.launch {
                                probeText = withContext(Dispatchers.Default) { BotHost.probe() }
                                busy = false
                            }
                        }
                    }
                    if (busy) Note("自检中…")
                    if (probeText.isNotBlank()) {
                        Text(
                            probeText,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }

                SectionCard(metrics, title = "bot 凭据", hint = "存在 App 私有目录，不上传") {
                    LineField(appid, { appid = it }, "AppID（纯数字）", numeric = true)
                    LineField(secret, { secret = it }, "AppSecret", password = true)
                    Text(
                        "QQ 开放平台的机器人后台可以随时重置 AppSecret，这里只是本地保存一份。",
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }

                SectionCard(metrics, title = "人格（内置在 APK 里）", hint = run {
                    val cur = PersonaAssets.selected(ctx)
                    if (cur.isBlank()) "还没选，默认会用未设定人格" else "当前：$cur"
                }) {
                    PersonaAssets.group(ctx).forEach { (label, names) ->
                        Text(
                            label,
                            fontSize = 11.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        )
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            names.forEach { name ->
                                Pill(name, selected = PersonaAssets.selected(ctx) == name) {
                                    val chars = PersonaAssets.select(ctx, name)
                                    msgOk = chars > 0
                                    msg = if (chars > 0) "已选「$name」· $chars 字，已写入运行目录"
                                    else "写入失败"
                                }
                            }
                        }
                    }
                    Text(
                        "完整版还原度最高但吃 token；精简版最省。选择会写进 App 私有目录的 persona.txt。",
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }

                SectionCard(metrics, title = "日志", hint = "每 2 秒刷新") {
                    if (logText.isBlank()) {
                        Text(
                            "还没有日志。点「启动」后这里会实时滚出来。",
                            fontSize = 12.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        )
                    } else {
                        Text(
                            logText,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }
            }
        }
    }
}

/** 极简 prefs 封装（只在纯 APK 模式里存两个字段） */
object Prefs {
    private fun sp(ctx: Context) =
        ctx.getSharedPreferences("andbna_local", Context.MODE_PRIVATE)

    fun get(ctx: Context, key: String): String =
        sp(ctx).getString(key, "") ?: ""

    fun put(ctx: Context, key: String, value: String) {
        sp(ctx).edit().putString(key, value.trim()).apply()
    }
}
