package com.wjljh.andbna.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.local.RunMode
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Back
import top.yukonga.miuix.kmp.theme.MiuixTheme
import androidx.compose.foundation.layout.PaddingValues

/**
 * 模式选择。
 *
 * 只在两种时候出现：第一次打开（还没配过），以及从设置里点「重新选择模式」。
 * 配过之后就默认按上次选的模式直接开跑，不再每次拦一下。
 */
@Composable
fun ModePickScreen(
    metrics: Metrics,
    current: RunMode?,
    allowBack: Boolean,
    onPick: (RunMode) -> Unit,
    onBack: () -> Unit,
) {
    var picked by remember { mutableStateOf(current) }

    Scaffold(
        containerColor = MiuixTheme.colorScheme.surface,
        topBar = {
            if (allowBack) {
                SmallTopAppBar(
                    title = "选择运行模式",
                    subtitle = "改完会立即生效",
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            androidx.compose.material3.Icon(MiuixIcons.Back, contentDescription = "返回")
                        }
                    },
                )
            } else {
                SmallTopAppBar(title = "欢迎使用 andbnA", subtitle = "先选一个运行方式")
            }
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState()),
        ) {
            PageColumn(metrics) {
                Text(
                    "这四种方式的区别只有一个：谁负责让 bot 一直活着。",
                    fontSize = 13.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )

                RunMode.entries.forEach { mode ->
                    Card(
                        cornerRadius = metrics.radiusCard,
                        insideMargin = PaddingValues(
                            horizontal = if (metrics.compact) 14.dp else 18.dp,
                            vertical = if (metrics.compact) 12.dp else 16.dp,
                        ),
                        onClick = { picked = mode },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Dot(if (picked == mode) Tokens.Pink else Tokens.Idle, 10.dp)
                            Column(Modifier.padding(start = 10.dp).weight(1f)) {
                                Text(
                                    mode.label,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MiuixTheme.colorScheme.onSurface,
                                )
                                Text(
                                    mode.summary,
                                    fontSize = 12.sp,
                                    color = if (picked == mode) Tokens.Pink
                                    else MiuixTheme.colorScheme.onSurfaceVariantSummary,
                                )
                                Text(
                                    mode.detail,
                                    fontSize = 11.sp,
                                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                                )
                            }
                        }
                        if (picked == mode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionChip("用这个模式") { onPick(mode) }
                            }
                        }
                    }
                }

                if (allowBack) {
                    ActionChip("返回，不改了") { onBack() }
                } else {
                    Text(
                        "选好之后，以后打开 App 就按这个模式直接开跑；想换的话在「设置 → 运行模式」里重新选。",
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
        }
    }
}
