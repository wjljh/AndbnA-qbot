package com.wjljh.andbna.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.wjljh.andbna.Panel
import org.json.JSONObject

/**
 * 页面数据的公共缓存。
 *
 * 为什么需要：之前每个页面的数据都挂在组件内部的 remember 上，
 * 一切走底部导航离开组合，状态就没了 —— 切回来必然重新发请求、
 * 重新解析，用户看到的就是"读一下才出东西"的卡顿。
 * 提到单例里之后，切页是**立刻有内容**，后台再刷新。
 *
 * 同时把"什么时候真的去请求"也收在这里：超过 maxAge 才发，
 * 避免来回点两下就请求两次。
 */
object Store {

    var status by mutableStateOf<JSONObject?>(null)
        private set
    var statusErr by mutableStateOf("")
        private set
    var statusAt by mutableStateOf(0L)
        private set

    var bots by mutableStateOf<List<JSONObject>>(emptyList())
        private set
    var botsAt by mutableStateOf(0L)
        private set

    var texts by mutableStateOf<JSONObject?>(null)
        private set
    var personas by mutableStateOf<List<String>>(emptyList())
        private set
    var textsAt by mutableStateOf(0L)
        private set

    var memory by mutableStateOf<JSONObject?>(null)
        private set
    var names by mutableStateOf<JSONObject?>(null)
        private set
    var memoryAt by mutableStateOf(0L)
        private set

    var config by mutableStateOf<JSONObject?>(null)
        private set
    var creds by mutableStateOf<JSONObject?>(null)
        private set
    var configAt by mutableStateOf(0L)
        private set

    var activeAppid by mutableStateOf("")
    var version by mutableStateOf("")

    /** 切 bot 时由界面直接改 */
    fun setActive(appid: String) {
        activeAppid = appid
    }

    private fun fresh(at: Long, maxAgeMs: Long) = at > 0 && System.currentTimeMillis() - at < maxAgeMs

    private fun jsonList(arr: org.json.JSONArray?): List<JSONObject> {
        if (arr == null) return emptyList()
        val out = ArrayList<JSONObject>(arr.length())
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
        return out
    }

    /** 状态：返回是否需要重画（拿到新数据就是 true） */
    suspend fun refreshStatus(maxAgeMs: Long = 1200): Boolean {
        if (fresh(statusAt, maxAgeMs) && status != null) return false
        val r = Panel.status()
        statusAt = System.currentTimeMillis()
        if (r.ok) {
            status = r.json
            statusErr = ""
            version = r.str("version")
            activeAppid = r.str("active")
            return true
        }
        statusErr = r.err().ifBlank { "HTTP ${r.code}" }
        return true
    }

    suspend fun refreshBots(maxAgeMs: Long = 5000) {
        if (fresh(botsAt, maxAgeMs)) return
        val r = Panel.bots()
        botsAt = System.currentTimeMillis()
        if (r.ok) {
            bots = jsonList(r.arr("bots"))
            activeAppid = r.str("active").ifBlank { activeAppid }
        }
    }

    suspend fun refreshTexts(maxAgeMs: Long = 4000) {
        if (fresh(textsAt, maxAgeMs)) return
        val t = Panel.texts()
        textsAt = System.currentTimeMillis()
        if (t.ok) texts = t.json
        val p = Panel.personas()
        if (p.ok) {
            val g = p.obj("groups") ?: JSONObject()
            val names = ArrayList<String>()
            listOf("完整", "精华", "精简", "其他").forEach { key ->
                val a = g.optJSONArray(key)
                if (a != null) for (i in 0 until a.length()) {
                    a.optJSONObject(i)?.optString("name")?.takeIf { it.isNotBlank() }?.let { names.add(it) }
                }
            }
            personas = names
        }
    }

    suspend fun refreshMemory(maxAgeMs: Long = 4000) {
        if (fresh(memoryAt, maxAgeMs)) return
        memoryAt = System.currentTimeMillis()
        val m = Panel.memory()
        if (m.ok) memory = m.json
        val n = Panel.names()
        if (n.ok) names = n.json
    }

    suspend fun refreshConfig(maxAgeMs: Long = 4000) {
        if (fresh(configAt, maxAgeMs)) return
        configAt = System.currentTimeMillis()
        val c = Panel.config()
        if (c.ok) config = c.json
        val cr = Panel.creds()
        if (cr.ok) creds = cr.json
    }

    /** 启动 / 切换 bot 之后强制作废，避免拿着上个 bot 的数据 */
    fun invalidateAll() {
        statusAt = 0; botsAt = 0; textsAt = 0; memoryAt = 0; configAt = 0
    }

    fun statusBot(): JSONObject? = status?.optJSONObject("bot")
    fun statusWatchdog(): JSONObject? = status?.optJSONObject("watchdog")
    fun statusNet(): JSONObject? = status?.optJSONObject("net")

    fun chats(): List<JSONObject> = jsonList(memory?.optJSONArray("chats"))
    fun nameRows(): List<JSONObject> = jsonList(names?.optJSONArray("names"))
    fun unnamedRows(): List<JSONObject> = jsonList(names?.optJSONArray("unnamed_in_memory"))
    fun textFiles(): List<JSONObject> = jsonList(texts?.optJSONArray("files"))
}
