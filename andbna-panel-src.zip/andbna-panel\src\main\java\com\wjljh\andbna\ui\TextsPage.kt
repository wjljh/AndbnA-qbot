package com.wjljh.andbna.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.theme.MiuixTheme

private val FILES = listOf("persona.txt", "phrases.json", "greetings.json")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextsPage(metrics: Metrics, visible: Boolean) {
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf("persona.txt") }
    var content by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var msgOk by remember { mutableStateOf(true) }

    suspend fun loadFile(name: String, onOk: (String) -> Unit) {
        loading = true
        val r = Panel.readText(name)
        loading = false
        if (r.ok) {
            onOk(r.str("content"))
            msgOk = true
            msg = "$name · ${r.str("content").length} 字"
        } else {
            msgOk = false
            msg = "读不出来：" + r.err()
        }
    }

    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        Store.refreshTexts()
        if (!loaded) {
            loadFile(picked) { content = it }
            loaded = true
        }
    }

    val personaChars = Store.texts?.optInt("persona_chars") ?: 0
    val personaSource = Store.texts?.optString("persona_source").orEmpty()
    val dir = Store.texts?.optString("dir").orEmpty()

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        PageColumn(metrics) {
            SectionCard(
                metrics,
                title = "角色预设",
                hint = if (personaSource.isNotBlank())
                    "当前人设来自 $personaSource（${personaChars} 字）" else "当前人设 ${personaChars} 字",
            ) {
                val names = Store.personas
                if (names.isEmpty()) {
                    Text(
                        "没有读到预设",
                        fontSize = 13.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    names.forEach { name ->
                        Pill(name) {
                            scope.launch {
                                msg = "正在切到「$name」…"
                                msgOk = true
                                val r = Panel.usePersona(name)
                                msgOk = r.ok
                                msg = if (r.ok) "已切到「$name」" else "切换失败：" + r.err()
                                Store.refreshTexts(0)
                                loadFile("persona.txt") { content = it }
                                picked = "persona.txt"
                            }
                        }
                    }
                }
                Text(
                    "完整版还原度最高但吃 token；精简版最省。切换会把当前人设备份到 persona_backup/。",
                    fontSize = 11.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }

            SectionCard(metrics, title = "编辑文件", hint = dir) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Store.textFiles().forEach { f ->
                        val n = f.optString("name")
                        val bytes = f.optInt("bytes")
                        Pill(if (bytes > 0) "$n · $bytes" else "$n · 无", selected = picked == n) {
                            picked = n
                            scope.launch { loadFile(n) { content = it } }
                        }
                    }
                }
                if (loading) Note("读取中…")
                if (msg.isNotBlank()) Note(msg, msgOk)
                LineField(
                    value = content,
                    onValueChange = { content = it },
                    label = picked,
                    singleLine = false,
                    minLines = if (metrics.compact) 8 else 12,
                    modifier = Modifier.height(if (metrics.compact) 220.dp else 300.dp),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionChip("保存") {
                        scope.launch {
                            msg = "正在写…"
                            msgOk = true
                            val r = Panel.writeText(picked, content)
                            msgOk = r.ok
                            msg = if (r.ok) "已保存（存盘后一分钟内自动生效）" else "写不进：" + r.err()
                            Store.refreshTexts(0)
                        }
                    }
                    ActionChip("重新读取") { scope.launch { loadFile(picked) { content = it } } }
                }
                Text(
                    "persona.txt 会被写进 personal.txt（自己改的那份优先，切预设时会备份让位）。\n" +
                        "phrases.json 存口癖、称呼、识图提示词；JSON 写坏了服务端会拒绝落盘。",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Default,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}
