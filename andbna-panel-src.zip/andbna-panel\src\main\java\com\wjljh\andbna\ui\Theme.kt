package com.wjljh.andbna.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

/**
 * 主题：外观完全交给 Miuix（小米 HyperOS 那一套）。
 *
 * 里面再包一层 MaterialTheme 只是为了兼容页面里已有的 MaterialTheme.colorScheme 引用 ——
 * 色板是从 Miuix 的色板**派生**出来的，所以不会出现两套颜色打架。
 * 粉色只作为点缀保留（状态点、选中项、强调按钮），不铺大面积。
 */
object Tokens {
    val Pink = Color(0xFFFF8FB1)
    val PinkDeep = Color(0xFFE5678F)

    val Ok = Color(0xFF3FBF7F)
    val Idle = Color(0xFFBFB5BB)
    val Bad = Color(0xFFE4574F)

    val RadiusCard = 28.dp
    val GapPage = 16.dp
    val GapCard = 12.dp
    val GapInner = 10.dp
}

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
)

@Composable
fun AndbnATheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val controller = remember {
        ThemeController(if (dark) ColorSchemeMode.Dark else ColorSchemeMode.Light)
    }
    MiuixTheme(controller = controller) {
        val m = MiuixTheme.colorScheme
        // 从 Miuix 色板派生 Material 色板：background 用 Miuix 的 surface（页面底色），
        // surface 用 surfaceContainer（卡片底色），这样卡片层次和系统一致。
        // 亮/暗必须分开建：之前写死 lightColorScheme，导致暗色模式下 Note 的
        // 错误条是浅粉底，在白底上用没问题，在暗色上刺眼。
        val bridge = if (dark) darkColorScheme(
            primary = Tokens.Pink,
            onPrimary = Color(0xFF3A2028),
            secondary = Tokens.PinkDeep,
            background = m.surface,
            onBackground = m.onSurface,
            surface = m.surfaceContainer,
            onSurface = m.onSurface,
            surfaceVariant = m.surfaceContainerHigh,
            onSurfaceVariant = m.onSurfaceVariantSummary,
            error = Color(0xFFFF8A80),
            onError = Color(0xFF3B0A06),
            errorContainer = Color(0xFF5A1F1A),
            onErrorContainer = Color(0xFFFFD9D4),
        ) else lightColorScheme(
            primary = Tokens.PinkDeep,
            onPrimary = Color.White,
            secondary = Tokens.Pink,
            background = m.surface,
            onBackground = m.onSurface,
            surface = m.surfaceContainer,
            onSurface = m.onSurface,
            surfaceVariant = m.surfaceContainerHigh,
            onSurfaceVariant = m.onSurfaceVariantSummary,
            error = Color(0xFFC6443C),
            onError = Color.White,
            errorContainer = Color(0xFFFFE1DE),
            onErrorContainer = Color(0xFF6B1C17),
        )
        MaterialTheme(colorScheme = bridge, typography = AppTypography, content = content)
    }
}
