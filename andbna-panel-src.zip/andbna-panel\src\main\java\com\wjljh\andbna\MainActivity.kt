package com.wjljh.andbna

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.wjljh.andbna.local.BotHost
import com.wjljh.andbna.ui.AndbnATheme
import com.wjljh.andbna.ui.PanelApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Panel.init(this)
        BotHost.init(this)
        enableEdgeToEdge()
        setContent {
            AndbnATheme {
                PanelApp()
            }
        }
    }
}
