package com.wjljh.andbna.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.PaddingValues
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Backup
import top.yukonga.miuix.kmp.icon.extended.Community
import top.yukonga.miuix.kmp.icon.extended.Info
import top.yukonga.miuix.kmp.icon.extended.Link
import top.yukonga.miuix.kmp.icon.extended.Messages
import top.yukonga.miuix.kmp.icon.extended.Notes
import top.yukonga.miuix.kmp.icon.extended.Ok
import top.yukonga.miuix.kmp.icon.extended.Play
import top.yukonga.miuix.kmp.icon.extended.Refresh
import top.yukonga.miuix.kmp.icon.extended.Settings
import top.yukonga.miuix.kmp.icon.extended.Timer
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun StatusPage(metrics: Metrics, visible: Boolean) {
    val scope = rememberCoroutineScope()
    var logText by remember { mutableStateOf("") }
    var llmMsg by remember { mutableStateOf("") }
    var llmOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf("") }

    // 只有这个页在显示时才轮询。之前四个页面各自无限循环，
    // 离开组合才停；现在至少不会在别的页面上偷偷发请求。
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (true) {
            Store.refreshStatus()
            delay(3000)
        }
    }

    val bot = Store.statusBot()
    val wd = Store.statusWatchdog()
    val net = Store.statusNet()
    val running = bot?.optBoolean("running") == true
    val netOk = net?.optBoolean("ok") == true

    val state = when {
        Store.status == null && Store.statusErr.isNotBlank() -> Triple("未连接", Tokens.Bad, "连不上面板服务")
        Store.status == null -> Triple("读取中", Tokens.Idle, "正在读取面板状态")
        running && netOk -> Triple("工作中", Tokens.Ok, "bot 在线，网络通畅")
        !running -> Triple("已停止", Tokens.Bad, "bot 进程没在跑")
        else -> Triple("网络异常", Tokens.Bad, "QQ 接口连不上，bot 会反复重连")
    }
    val modeLabel = com.wjljh.andbna.local.ModeStore.get(
        androidx.compose.ui.platform.LocalContext.current
    )?.label ?: "未选模式"

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
    ) {
        PageColumn(metrics) {
            HeroCard(metrics, state.first, state.second, state.third)

            SectionCard(metrics, gap = 2.dp) {
                InfoRow(MiuixIcons.Info, "面板版本", Store.version.ifBlank { "未连接" })
                RowDivider()
                InfoRow(MiuixIcons.Link, "面板地址", Panel.host.ifBlank { "127.0.0.1:8788" })
                RowDivider()
                InfoRow(MiuixIcons.Settings, "运行模式", modeLabel)
                RowDivider()
                InfoRow(
                    MiuixIcons.Community, "bot 进程",
                    when {
                        bot == null -> "-"
                        running -> "pid ${bot.optInt("pid")} · 已跑 ${fmtDur(bot.optInt("uptime_sec"))}"
                        else -> "没在跑"
                    },
                )
                RowDivider()
                InfoRow(
                    MiuixIcons.Refresh, "看门狗",
                    when {
                        wd == null -> "-"
                        wd.optBoolean("running") ->
                            "运行中" + wd.optString("appid").let { if (it.isBlank()) "" else " · 守护 $it" }
                        else -> "没在跑"
                    },
                )
                RowDivider()
                InfoRow(
                    MiuixIcons.Timer, "内存 / CPU",
                    if (bot == null) "-"
                    else "${bot.optDouble("rss_mb")} MB · 累计 ${bot.optDouble("cpu_sec")} 秒",
                )
            }

            SectionCard(metrics, title = "快捷操作") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ConfirmButton(text = "重启 bot", confirmText = "确认重启？", danger = true) {
                        scope.launch {
                            busy = "正在重启…"
                            val r = Panel.restart("bot")
                            busy = if (r.ok) "" else "重启失败：" + r.err()
                            delay(2500)
                            Store.refreshStatus(0)
                        }
                    }
                    ConfirmButton(text = "重启看门狗", confirmText = "确认重启？", danger = false) {
                        scope.launch {
                            busy = "正在拉起看门狗…"
                            val r = Panel.restart("watchdog")
                            busy = if (r.ok) "" else "失败：" + r.err()
                            Store.refreshStatus(0)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionChip("试跑模型") {
                        scope.launch {
                            llmMsg = "正在调模型…"
                            llmOk = true
                            val r = Panel.testLlm()
                            llmOk = r.ok
                            llmMsg = if (r.ok) {
                                "可用 · ${r.json?.optInt("ms")}ms · ${r.str("reply").ifBlank { "（空回复）" }}"
                            } else {
                                "失败：" + r.err()
                            }
                        }
                    }
                    ActionChip("读日志") {
                        scope.launch {
                            val r = Panel.log(150)
                            logText = if (r.ok) {
                                val arr = r.arr("lines")
                                buildString {
                                    if (arr != null) for (i in 0 until arr.length()) {
                                        append(arr.optString(i)).append('\n')
                                    }
                                }.ifBlank { "（日志是空的）" }
                            } else {
                                "读取失败：" + r.err()
                            }
                        }
                    }
                }
                if (busy.isNotBlank()) Note(busy)
                if (llmMsg.isNotBlank()) Note(llmMsg, llmOk)
            }

            if (logText.isNotBlank()) {
                SectionCard(metrics, title = "日志（最近 150 行）") {
                    Text(
                        logText,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
        }
    }
}

/** 顶部状态卡：带底色的大块状态区，参考 SukiSU 主界面那一块 */
@Composable
private fun HeroCard(metrics: Metrics, title: String, tint: Color, subtitle: String) {
    val modeLabel = com.wjljh.andbna.local.ModeStore.get(
        androidx.compose.ui.platform.LocalContext.current
    )?.label ?: "本机托管"
    Card(
        cornerRadius = metrics.radiusCard,
        insideMargin = PaddingValues(
            horizontal = if (metrics.compact) 16.dp else 20.dp,
            vertical = if (metrics.compact) 16.dp else 20.dp,
        ),
        // 卡片本身染色（SukiSU 那块是带绿底的），不是只有图标染色
        colors = CardDefaults.defaultColors(color = tint.copy(alpha = 0.16f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.fillMaxWidth(0.74f)) {
                Text(
                    title,
                    fontSize = if (metrics.compact) 22.sp else 26.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = tint,
                )
                Spacer(Modifier.size(2.dp))
                Text(
                    listOf("面板 " + Store.version.ifBlank { "—" }, modeLabel).joinToString(" · "),
                    fontSize = 12.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle,
                    fontSize = 11.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(tintIcon(title), contentDescription = null, tint = tint, modifier = Modifier.size(30.dp))
            }
        }
    }
}

private fun tintIcon(title: String): ImageVector = when (title) {
    "工作中" -> MiuixIcons.Ok
    "已停止", "网络异常", "未连接" -> MiuixIcons.Notes
    else -> MiuixIcons.Info
}

/** 带前置图标的信息行：标题在上、值在下，和下 SukiSU 那排（管理器版本 / 内核版本 …）同一个结构 */
@Composable
private fun InfoRow(icon: ImageVector, title: String, value: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            modifier = Modifier.size(22.dp),
        )
        Column(Modifier.padding(start = 14.dp).weight(1f)) {
            Text(
                title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MiuixTheme.colorScheme.onSurface,
            )
            Text(
                value,
                fontSize = 12.sp,
                lineHeight = 15.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 36.dp)
            .height(0.6.dp)
            .background(MiuixTheme.colorScheme.onSurfaceVariantSummary.copy(alpha = 0.15f)),
    )
}

private fun fmtDur(sec: Int): String {
    if (sec <= 0) return "—"
    val d = sec / 86400
    val h = (sec % 86400) / 3600
    val m = (sec % 3600) / 60
    return when {
        d > 0 -> "$d 天 $h 小时"
        h > 0 -> "$h 小时 $m 分"
        m > 0 -> "$m 分"
        else -> "$sec 秒"
    }
}
