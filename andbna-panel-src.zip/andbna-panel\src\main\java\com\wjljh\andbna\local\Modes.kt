package com.wjljh.andbna.local

import android.content.Context

/**
 * 三种（四种）托管方式。
 *
 * 它们的区别只有一个：**谁来让 bot 进程活着**。
 *  - 普通：App 自己的前台服务（零门槛，但会被厂商省电策略杀）
 *  - ADB ：借 Shizuku 提到 shell 权限，起独立进程（重启后要手动起）
 *  - root：写 /data/adb/service.d/ 开机脚本 + 电池白名单（最稳）
 *  - 模块：连接已装的 KernelSU 模块面板（最稳，但要装模块）
 */
enum class RunMode(
    val key: String,
    val label: String,
    val summary: String,
    val detail: String,
) {
    NORMAL(
        "normal", "普通模式",
        "bot 跑在 App 里，前台服务保活",
        "不需要模块、不需要 root。代价：HyperOS 等省电策略可能把它清掉，掉线期间的消息平台不补发。",
    ),
    ADB(
        "adb", "ADB 模式",
        "借 Shizuku 起独立进程",
        "进程不依赖 App 存活，比普通模式稳。前提：装 Shizuku 并用无线调试授权；重启后要重新拉起。",
    ),
    ROOT(
        "root", "root 模式",
        "开机自启 + 电池白名单",
        "会往 /data/adb/service.d/ 写一个开机启动脚本，并把 App 加进电池优化白名单。最稳，但会改系统配置。",
    ),
    MODULE(
        "module", "模块模式",
        "连接已装的 KernelSU 模块面板",
        "bot 由模块的 root 服务托管（服务 + tmux + 看门狗）。需要先装 andbnA 模块（v9.46+）。",
    );

    companion object {
        fun of(key: String?): RunMode? = entries.firstOrNull { it.key == key }
    }
}

/** 模式选择结果存在 App 私有 prefs 里 */
object ModeStore {
    private const val PREF = "andbna_mode"

    fun get(ctx: Context): RunMode? =
        RunMode.of(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("mode", null))

    /**
     * 启动时用的模式。
     *
     * 不再把模式选择拦在最前面：没选过就自动推断——
     * 已经配过面板 token 的走模块模式，否则走本机普通模式。
     * 想换在「设置 → 运行模式」里进去。
     */
    fun initial(ctx: Context): RunMode {
        get(ctx)?.let { return it }
        return if (com.wjljh.andbna.Panel.configured) RunMode.MODULE else RunMode.NORMAL
    }

    fun set(ctx: Context, mode: RunMode) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString("mode", mode.key).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
