package com.wjljh.andbna.local

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.wjljh.andbna.MainActivity
import java.io.File

/**
 * 纯 APK 模式的托管入口：bot 跑在 App 自己的进程里。
 *
 * 为什么必须是前台服务：Android 会随时回收后台进程，而 QQ 官方机器人
 * 断线期间的消息平台不补发 —— 被杀了就是真丢消息。前台服务把进程钉住，
 * 通知栏也能让用户随时知道「它现在活着」。
 */
class BotService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        if (action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val appid = intent?.getStringExtra(EXTRA_APPID).orEmpty()
        val secret = intent?.getStringExtra(EXTRA_SECRET).orEmpty()

        startForeground(NOTIF_ID, buildNotification("正在启动…", "准备 Python 运行时"))

        val ok = BotHost.start(this, appid, secret)
        pinNotification(if (ok) "运行中" else "启动失败", BotHost.statusLine())
        return START_STICKY
    }

    override fun onDestroy() {
        BotHost.stop()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(CHANNEL_ID, "andbnA 本机 Bot", NotificationManager.IMPORTANCE_LOW)
        ch.description = "bot 运行时挂着，告诉你有它在跑"
        ch.setShowBadge(false)
        mgr.createNotificationChannel(ch)
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun pinNotification(title: String, text: String) {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        mgr.notify(NOTIF_ID, buildNotification(title, text))
    }

    companion object {
        const val CHANNEL_ID = "andbna_local_bot"
        const val NOTIF_ID = 4711
        const val ACTION_START = "com.wjljh.andbna.START_LOCAL"
        const val ACTION_STOP = "com.wjljh.andbna.STOP_LOCAL"
        const val EXTRA_APPID = "appid"
        const val EXTRA_SECRET = "secret"

        fun start(context: Context, appid: String, secret: String) {
            val i = Intent(context, BotService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_APPID, appid)
                putExtra(EXTRA_SECRET, secret)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BotService::class.java))
        }
    }
}

/**
 * 内嵌 Python 的门面：负责初始化解释器、拉起 bot_runner、把状态借给界面看。
 *
 * 注意：Chaquopy 的 Python.start 只能调一次，进程内共用。
 */
object BotHost {

    private var module: PyObject? = null
    private var started = false
    var lastError: String = ""
        private set

    val pythonReady: Boolean get() = Python.isStarted()

    private fun ensurePython(context: Context): Boolean {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context.applicationContext))
        }
        module = module ?: try {
            Python.getInstance().getModule("bot_runner")
        } catch (e: Throwable) {
            lastError = "加载 bot_runner 失败：${e.message}"
            null
        }
        return module != null
    }

    fun dataDir(context: Context): File {
        val d = File(context.filesDir, "localbot")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun start(context: Context, appid: String, secret: String): Boolean {
        if (!ensurePython(context)) return false
        return try {
            val r = module!!.callAttr(
                "start", appid, secret, dataDir(context).absolutePath
            ).toString()
            started = r == "OK"
            if (!started) lastError = r
            started
        } catch (e: Throwable) {
            lastError = "启动异常：${e.message}"
            false
        }
    }

    fun stop() {
        try {
            module?.callAttr("stop")
        } catch (_: Throwable) {
        }
        started = false
    }

    fun isRunning(): Boolean = try {
        module?.callAttr("is_running")?.toBoolean() ?: false
    } catch (e: Throwable) {
        false
    }

    fun statusLine(): String = try {
        module?.callAttr("status")?.toString() ?: "未启动"
    } catch (e: Throwable) {
        lastError.ifBlank { "未启动" }
    }

    fun logTail(n: Int = 120): String = try {
        module?.callAttr("log_text", n)?.toString() ?: ""
    } catch (e: Throwable) {
        ""
    }

    /** 各层依赖的版本自检，用来判断这套 Python 运行时到底好不好使 */
    fun probe(): String = try {
        val ctx = _ctx
        if (ctx == null) {
            "还没初始化"
        } else if (!ensurePython(ctx)) {
            "Python 没起来"
        } else {
            module?.callAttr("probe")?.toString() ?: ""
        }
    } catch (e: Throwable) {
        "自检失败：${e.message}"
    }

    private var _ctx: Context? = null

    /** 只记下上下文；Python 解释器等到真要用时再起（启动它比较重） */
    fun init(context: Context) {
        _ctx = context.applicationContext
    }
}
