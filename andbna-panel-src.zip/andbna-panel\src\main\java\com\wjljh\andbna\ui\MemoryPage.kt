package com.wjljh.andbna.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.theme.MiuixTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemoryPage(metrics: Metrics, visible: Boolean) {
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var msgOk by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf("") }
    var editText by remember { mutableStateOf("") }

    LaunchedEffect(visible) {
        if (visible) Store.refreshMemory()
    }

    val chats = Store.chats()
    val names = Store.nameRows()
    val unnamed = Store.unnamedRows()
    val dir = Store.memory?.optString("dir").orEmpty()

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        PageColumn(metrics) {
            if (msg.isNotBlank()) Note(msg, msgOk)

            SectionCard(
                metrics,
                title = "会话",
                hint = if (dir.isBlank()) null else dir.replace("/data/data/com.termux/files/home/", "~/"),
            ) {
                if (chats.isEmpty()) {
                    Text(
                        "还没有记忆",
                        fontSize = 13.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
                chats.forEach { c ->
                    val key = c.optString("key")
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${c.optString("type")} · ${key.take(18)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                fontFamily = FontFamily.Monospace,
                                color = MiuixTheme.colorScheme.onSurface,
                            )
                            Text(
                                buildString {
                                    append("${c.optInt("count")} 条 · ${c.optString("last")}")
                                    val who = c.optJSONArray("who")
                                    if (who != null && who.length() > 0) {
                                        append(" · ")
                                        for (i in 0 until minOf(who.length(), 4)) {
                                            if (i > 0) append("、")
                                            append(who.optString(i))
                                        }
                                    }
                                },
                                fontSize = 11.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        ConfirmButton(text = "删", confirmText = "确认删？") {
                            scope.launch {
                                msg = "正在删…"
                                val r = Panel.deleteChat(key)
                                msgOk = r.ok
                                msg = if (r.ok) "已删除 $key" else "删除失败：" + r.err()
                                Store.refreshMemory(0)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ConfirmButton(text = "删 30 天前", confirmText = "确认？", danger = false) {
                        scope.launch {
                            msg = "正在清旧条目…"
                            val r = Panel.deleteOld(30)
                            msgOk = r.ok
                            msg = if (r.ok) "已清掉 30 天前的条目" else "失败：" + r.err()
                            Store.refreshMemory(0)
                        }
                    }
                    ConfirmButton(text = "清空全部", confirmText = "真的清空？") {
                        scope.launch {
                            msg = "正在清空…"
                            val r = Panel.purgeMemory()
                            msgOk = r.ok
                            msg = if (r.ok) "记忆已清空（原文件已备份到 memory_backup/）" else "失败：" + r.err()
                            Store.refreshMemory(0)
                        }
                    }
                }
            }

            SectionCard(metrics, title = "称呼表", hint = "记忆里她怎么叫这些人") {
                names.forEach { n ->
                    val uid = n.optString("uid")
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                n.optString("name") + if (n.optBoolean("auto")) "（自动）" else "",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MiuixTheme.colorScheme.onSurface,
                            )
                            Text(
                                "${uid.take(16)} · ${n.optInt("count")} 条 · ${n.optString("last")}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        if (editing == uid) {
                            Pill("取消") { editing = "" }
                        } else {
                            Pill("改名") {
                                editing = uid
                                editText = n.optString("name")
                            }
                        }
                    }
                    if (editing == uid) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        ) {
                            LineField(editText, { editText = it }, "新称呼", modifier = Modifier.weight(1f))
                            ActionChip("保存") {
                                scope.launch {
                                    // setname 第一个参数是旧称呼，第二个是新称呼
                                    val r = Panel.rename(n.optString("name"), editText)
                                    msgOk = r.ok
                                    msg = if (r.ok) "已改名" else "失败：" + r.err()
                                    editing = ""
                                    Store.refreshMemory(0)
                                }
                            }
                        }
                    }
                }
                if (names.isEmpty()) {
                    Text(
                        "称呼表还是空的",
                        fontSize = 13.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                }
                if (unnamed.isNotEmpty()) {
                    Text(
                        "记忆里出现过、但还没进称呼表的：",
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        unnamed.take(20).forEach { u ->
                            Pill("${u.optString("name")} · ${u.optInt("count")}") {
                                scope.launch {
                                    val r = Panel.rename(u.optString("name"), u.optString("name"))
                                    msgOk = r.ok
                                    msg = if (r.ok) "已收进称呼表" else "失败：" + r.err()
                                    Store.refreshMemory(0)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
