package com.wjljh.andbna.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.wjljh.andbna.local.ModeStore
import com.wjljh.andbna.local.RunMode
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.ChevronForward
import top.yukonga.miuix.kmp.icon.extended.Settings
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjljh.andbna.Panel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsPage(
    metrics: Metrics,
    visible: Boolean,
    onBotChanged: (String) -> Unit,
    onReselectMode: () -> Unit = {},
) {
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var msgOk by remember { mutableStateOf(true) }

    // 回复行为
    var judge by remember { mutableStateOf("llm") }
    var judgeModel by remember { mutableStateOf("") }
    var chatProb by remember { mutableStateOf("0.3") }
    var dailyLimit by remember { mutableStateOf("50") }
    var greetingHours by remember { mutableStateOf("8,21") }

    // 凭据
    var credMasked by remember { mutableStateOf<JSONObject?>(null) }
    var secretInput by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }
    var apiInput by remember { mutableStateOf("") }
    var modelInput by remember { mutableStateOf("") }
    var appidInput by remember { mutableStateOf("") }

    // bot 管理
    var bots by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var newAppid by remember { mutableStateOf("") }
    var newSecret by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf("") }
    var inherit by remember { mutableStateOf(true) }
    var activeAppid by remember { mutableStateOf("") }

    suspend fun loadConfig() {
        val r = Panel.config()
        if (r.ok) {
            val b = r.obj("bot") ?: JSONObject()
            judge = b.optString("reply_judge", "llm").ifBlank { "llm" }
            judgeModel = b.optString("judge_model", "")
            chatProb = b.optDouble("chat_prob", 0.3).toString()
            val oa = b.optJSONObject("official_active")
            dailyLimit = (oa?.optInt("daily_limit") ?: 50).toString()
            val gh = oa?.optJSONArray("greeting_hours")
            greetingHours = buildString {
                if (gh != null) for (i in 0 until gh.length()) {
                    if (i > 0) append(',')
                    append(gh.optInt(i))
                }
            }
            activeAppid = r.obj("global")?.optString("active_appid").orEmpty()
        } else {
            msgOk = false
            msg = "读配置失败：" + r.err()
        }
    }

    suspend fun loadCreds() {
        val r = Panel.creds()
        if (r.ok) {
            val f = r.obj("fields")
            credMasked = f
            apiInput = f?.optJSONObject("llm_api")?.optString("value").orEmpty()
            modelInput = f?.optJSONObject("llm_model")?.optString("value").orEmpty()
            appidInput = f?.optJSONObject("appid")?.optString("masked").orEmpty()
        }
    }

    suspend fun loadBots() {
        val r = Panel.bots()
        if (r.ok) {
            val a: JSONArray? = r.arr("bots")
            val l = mutableListOf<JSONObject>()
            if (a != null) for (i in 0 until a.length()) l.add(a.getJSONObject(i))
            bots = l
            activeAppid = r.str("active").ifBlank { activeAppid }
        }
    }

    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        loadConfig()
        loadCreds()
        loadBots()
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        PageColumn(metrics) {
            if (msg.isNotBlank()) Note(msg, msgOk)

            SectionCard(metrics, title = "回复策略", hint = "改了立刻热生效，不用重启") {
                Text("别人在群里说话时要不要插话", fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("模型判断", selected = judge == "llm") { judge = "llm" }
                    Pill("随机", selected = judge == "random") { judge = "random" }
                }
                Note(
                    "模型判断更自然，但每次非@消息都会多调一次小模型；随机最省。\n" +
                        "判定请用非推理模型（如 deepseek-chat），推理模型会把额度花在思考上导致正文为空。",
                )
                LineField(judgeModel, { judgeModel = it }, "判定用的模型（可空）")
                LineField(chatProb, { chatProb = it }, "闲聊概率 0~1", numeric = true)
                LineField(dailyLimit, { dailyLimit = it }, "每天最多回复条数", numeric = true)
                LineField(greetingHours, { greetingHours = it }, "问候时段，逗号分隔（如 8,21）")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionChip("保存") {
                        scope.launch {
                            val hours = greetingHours.split(',', '，')
                                .mapNotNull { it.trim().toIntOrNull() }
                            val patch = JSONObject()
                                .put("reply_judge", judge)
                                .put("judge_model", judgeModel.trim())
                                .put("chat_prob", chatProb.toDoubleOrNull() ?: 0.3)
                            val oa = JSONObject()
                                .put("enabled", true)
                                .put("daily_limit", dailyLimit.toIntOrNull() ?: 50)
                                .put("greeting_hours", JSONArray(hours))
                            patch.put("official_active", oa)
                            val r = Panel.saveConfig("bot", patch)
                            msgOk = r.ok
                            msg = if (r.ok) "配置已保存" else "保存失败：" + r.err()
                            loadConfig()
                        }
                    }
                    ActionChip("重新读取") { scope.launch { loadConfig() } }
                }
            }

            SectionCard(
                metrics,
                title = "凭据",
                hint = "只显示掩码；留空表示不改",
            ) {
                val f = credMasked
                KeyValue("AppID", f?.optJSONObject("appid")?.optString("masked").orEmpty()
                    .ifBlank { "未设置" }, mono = true)
                KeyValue("AppSecret", f?.optJSONObject("secret")?.optString("masked").orEmpty()
                    .ifBlank { "未设置" }, mono = true)
                KeyValue("模型 Key", f?.optJSONObject("llm_key")?.optString("masked").orEmpty()
                    .ifBlank { "未设置" }, mono = true)
                LineField(secretInput, { secretInput = it }, "新 AppSecret（留空不改）", password = true)
                LineField(keyInput, { keyInput = it }, "新模型 Key（留空不改）", password = true)
                LineField(apiInput, { apiInput = it }, "模型地址", password = false)
                LineField(modelInput, { modelInput = it }, "模型名")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionChip("保存凭据") {
                        scope.launch {
                            val fields = JSONObject()
                            if (secretInput.isNotBlank()) fields.put("secret", secretInput.trim())
                            if (keyInput.isNotBlank()) fields.put("llm_key", keyInput.trim())
                            if (apiInput.isNotBlank()) fields.put("llm_api", apiInput.trim())
                            if (modelInput.isNotBlank()) fields.put("llm_model", modelInput.trim())
                            if (fields.length() == 0) {
                                msgOk = false
                                msg = "什么都没填"
                            } else {
                                val r = Panel.saveCreds(fields)
                                msgOk = r.ok
                                msg = if (r.ok) {
                                    "已写入：重启 bot 后生效（状态页有重启按钮）"
                                } else {
                                    "保存失败：" + r.err()
                                }
                                secretInput = ""
                                keyInput = ""
                                loadCreds()
                            }
                        }
                    }
                    ActionChip("重新读取") { scope.launch { loadCreds() } }
                }
            }

            SectionCard(metrics, title = "bot 管理", hint = "一个 AppID 一个身份，同时只跑一个") {
                bots.forEach { b ->
                    val appid = b.optString("appid")
                    val current = b.optBoolean("current")
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    ) {
                        Dot(if (current) Tokens.Ok else Tokens.Idle)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(
                                appid,
                                fontSize = 13.sp,
                                fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace,
                            )
                            Text(
                                buildString {
                                    append(if (current) "当前" else "备用")
                                    append(" · 会话 ${b.optInt("chats")} · 记忆 ${b.optInt("entries")}")
                                    if (!b.optBoolean("cred_match", true)) append(" · ⚠ 凭据 AppID 与目录不符")
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (!current) {
                            ConfirmButton(text = "切换", confirmText = "会重启", danger = false) {
                                scope.launch {
                                    val r = Panel.useBot(appid)
                                    msgOk = r.ok
                                    msg = if (r.ok) "已切到 $appid" else "失败：" + r.err()
                                    loadBots()
                                    onBotChanged(appid)
                                }
                            }
                        }
                        ConfirmButton(text = "删除", confirmText = "确认删？") {
                            scope.launch {
                                val r = Panel.deleteBot(appid)
                                msgOk = r.ok
                                msg = if (r.ok) "已移到 deleted_bots/（不是真删，可以找回）" else "失败：" + r.err()
                                loadBots()
                            }
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
                Text("新建 bot", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                LineField(newAppid, { newAppid = it }, "AppID（纯数字）", numeric = true)
                LineField(newSecret, { newSecret = it }, "AppSecret", password = true)
                LineField(newRole, { newRole = it }, "角色预设名（可空）")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("继承当前 bot 的模型配置", selected = inherit) { inherit = !inherit }
                }
                ActionChip("创建") {
                    scope.launch {
                        if (newAppid.isBlank()) {
                            msgOk = false
                            msg = "AppID 不能空"
                        } else {
                            msg = "正在创建…"
                            msgOk = true
                            val r = Panel.newBot(newAppid.trim(), newSecret.trim(), newRole.trim(), inherit)
                            msgOk = r.ok
                            val log = r.arr("log")
                            msg = if (r.ok) {
                                buildString {
                                    append("已创建 ${newAppid.trim()}\n")
                                    if (log != null) for (i in 0 until log.length()) {
                                        append(log.optString(i)).append('\n')
                                    }
                                    append("到抽屉里切换成它即可上线")
                                }
                            } else {
                                "创建失败：" + r.err()
                            }
                            newAppid = ""
                            newSecret = ""
                            loadBots()
                        }
                    }
                }
            }

            // 运行模式：不放在设置最上面，做成一个带箭头的二级入口
            val ctx = LocalContext.current
            val curMode = ModeStore.initial(ctx)
            SectionCard(metrics, title = "高级") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onReselectMode() }
                        .padding(vertical = 4.dp),
                ) {
                    Icon(
                        MiuixIcons.Settings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp),
                    )
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        Text(
                            "运行模式",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            "${curMode.label} · ${curMode.summary}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Icon(
                        MiuixIcons.ChevronForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }

            SectionCard(metrics, title = "关于") {
                KeyValue("面板地址", Panel.host, mono = true)
                KeyValue("TOKEN", if (Panel.token.isBlank()) "未设置" else
                    Panel.token.take(6) + "…" + Panel.token.takeLast(4), mono = true)
                KeyValue("当前 bot", activeAppid.ifBlank { "—" }, mono = true)
                Note(
                    "面板只连手机本机（panel.py 绑 127.0.0.1）。bot 本体跑在模块里，" +
                        "关掉这个 App 不影响它。",
                )
                ConfirmButton(text = "重新设置连接", confirmText = "确认清掉？", danger = false) {
                    Panel.token = ""
                    Panel.host = ""
                    msgOk = true
                    msg = "已清掉，重新打开 App 会回到连接页"
                }
            }
        }
    }
}
